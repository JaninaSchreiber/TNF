#!/bin/sh

export EXTRAE_CONFIG_FILE=extrae.xml
export LD_PRELOAD=${EXTRAE_HOME}/lib/libomptrace.so

## Run the desired program
./swift_run_sweep.sh extraetest ../data/sweep_test.txt
