#!/bin/bash/

bash /gpfs/scratch/bsc08/bsc08204/PhysiBoss-Nina/spheroid-tnf-v2-emews-new/data/PhysiBoSSv2/spheroid_TNF_v2 {"user_parameters.concentration_tnf": 0.03776946789709024, "user_parameters.duration_add_tnf": 21.381624867847595, "user_parameters.time_add_tnf": 371.7609678235103}

