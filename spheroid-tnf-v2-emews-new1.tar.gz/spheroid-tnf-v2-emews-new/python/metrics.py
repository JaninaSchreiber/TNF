import numpy as np
import pandas as pd
import os


PATH = "../../"

class metrics:
    """
    A set of metrics for evaluating model exploration methods
    """
    def __init__(self, cols, replications, mem):
        self.scores = []
        self.replications = replications
        self.results = pd.DataFrame(columns=cols)
        self.mem = mem
        self.len_simulation = 0


    def append_score(self, score, x_current, cols):
        """
        List of  points in the Markov Chain and the according objective
        function values.

        Parameters
        -----------
        score : float
                objective function values
        x_current : row of pandas DataFrame
                parameter values of current position
        cols : list of strings
                column names of parameters
        """
        # saves the values of f_x
        self.scores.append(score)
        # saves the values with
        mylist = list(x_current.values())
        self.results = self.results.append(pd.DataFrame([mylist + [score]],
                                                        columns=cols))

    def get_nr_of_evaluations(self):
        """
        Number of objective function evaluations.

        Notes:
        ------
        Number of evaluated points multiplied with the number of
        times a point is replicated (to account for stochasticity in the
        simulation).
        """
        return self.replications * len(self.scores)
    

    def get_optimum(self):
        """
        lowest objective function value
        """
        opt = self.results[self.results["score"] == self.results["score"][0].min()]
        return opt

    def get_memory_use(self):
        return self.mem                 
 
    def calculate_simulation_time(self, t_send_data, t_receive_data):
        """
        time to run the simulation
 
        Parameters
        ----------
        t_send_data : time
                      time of starting the simulation
        t_receive_data : time
                      time of ending the simulation
        """
        self.len_simulation = self.len_simulation + (t_receive_data - t_send_data)

    def calculate_alg_time(self, ts_all, te_all):
        """
        return the runtime of the algorithm without the simulation
     
        Parameters
        ----------
        ts_all : time
        te_al : time
        """
        return te_all - (self.len_simulation + ts_all)

    def calculate_total_time(self, ts_all, te_all):
        """ 
        return the runtime of the algorithm with the simulation
       
        Parameters
        ----------
        ts_all : time
                 time when the search algorithm starts
        te_all : time
                 time when the search algorithm ends
        """
        return te_all - ts_all

    def write_results(self, directory):
        self.results.to_csv(directory + "/results.csv")

        
def summarize_results(met, ts_all, te_all):
    instance_dir = os.environ["TURBINE_OUTPUT"]
    optimum = met.get_optimum().to_dict()
    total_time = met.calculate_total_time(ts_all, te_all)
    alg_time = met.calculate_alg_time(ts_all, te_all)
    nr_of_evaluations = met.get_nr_of_evaluations()
    mem = met.get_memory_use()

    # create result dict
    result_dict = {"experiment": [instance_dir.split("/")[-1]],
                   "total_time": [total_time],
                   "alg_time": [alg_time],
                   "nr_of_evaluations": [nr_of_evaluations],
                   "rss": [mem.rss],
                   "uss": [mem.uss]}

    df = pd.DataFrame.from_dict(result_dict)
    df = pd.concat([df, pd.DataFrame(optimum)], axis=1)
    print(df)

    directory = instance_dir + "/mymetrics/"
    if not os.path.exists(directory):
        os.makedirs(directory)
    df.to_csv(directory + "summary.csv")
    met.write_results(directory)


