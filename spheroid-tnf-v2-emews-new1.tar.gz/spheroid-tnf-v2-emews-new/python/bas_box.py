import time
import json
import sys
import time
import metrics
import psutil
import os
import random
import pandas as pd
import numpy as np
import scipy
from scipy import stats
from random import randrange,choices, triangular
from patternhitandrun import PatternHitAndRun

import eqpy, metrics, ga_utils


def randrange_float(start, stop, step):
    return random.randint(0, int((stop - start) / step)) * step + start
       
def obj_func():
    return 0


def printf(val):
    #print(val)
    sys.stdout.flush()


def queue_map(obj_func, pops):
    # Note that the obj_func is not used
    # sending data that looks like:
    # [[a,b,c,d],[e,f,g,h],...]
    # print(pops) 
    if not pops:
        return []
    eqpy.OUT_put(str(pops).replace("\'", "\""))
    printf(pops)
    result = eqpy.IN_get()
    printf("queue_map: {}".format(result))
    split_result = result.split(',')
    # returns the objective function value
    return [(float(x),) for x in split_result]


def prepare_x(bas_params, x_param):
    x = dict(zip(bas_params.index, eval(x_param)))
    x = str(x).replace("'", "\"")
    return x


def improving_hit_and_run(sim):
    """
    move to the proposed point
    if the obj. function value improved

    Parameters
    ----------
    sim : object of class `PatternHitAndRun`  
         can be instantiated with sim = bas_algorithm(m_max, data)

    Returns
    --------
    sim : object of class PatternHitAndRun
          updates the current point in the search space

    """
    if(sim.f_x < sim.f_x_last):
        sim.set_x_current()
        sim.f_x_last = sim.f_x
    elif(sim.f_x >= sim.f_x_last):
        pass
        #print("The point did not improve")
    return sim


def hide_and_seek(sim, m, t, met, cooling_schedule='geometric'):
    """
    decide whether or not to move to the proposed 
    point depending on the state. Always move to imporivng points.
    
    Parameters
    -----------
    sim : object of class PatternHitAndRun
       can be instantiated with sim = PatternHitAndRun(m_max, data)
    m : int
       iteration number
    t : float 
       value of the current cooling
    met : object of class metrics
       calculates the runtime, memory usage, etc.
    cooling_schedule: string, optional
       default: 'geometric'
       other: 'adaptive'

    Returns
    --------
    sim : object of class PatternHitAndRun
          updates the current point in the search space
    t : float
          cooling parameter
    """
    if(sim.f_x < sim.f_x_last):
        sim.set_x_current()
        sim.set_f_x_last(sim.f_x)
        if(cooling_schedule == 'adaptive'):
            degree_of_freedom = sim.data.loc['xc'].size
            t = 2*(sim.f_x_last - 0)/stats.chi2.ppf(0.95, degree_of_freedom)
    else:
        p_accept = min(1, float(np.exp((sim.f_x_last - sim.f_x)/t)))
        set_x = int(np.random.choice([0, 1], 1, p=[1-p_accept, p_accept])) #x , x_proposal
        if set_x == 0:
            pass
        elif set_x == 1:
            sim.set_x_current()
            sim.set_f_x_last(sim.f_x)
    if(cooling_schedule == 'geometric'):
        t = 0.99**m
    return sim, t

        
def bas_optimize(bas_params, strategy, num_iter=100, save=True, cooling_schedule="adaptive", replications=1):     
    """
    Parameters:
    -----------
    num_iter : int
              maximum number of iterations
    strategy : string
              optimization method 'HNS' or 'IHR'
    cooling_schedule : string
              only for 'hide-and-seek'; 'adaptive' or 'geometric'
    """

    
    # implementation of metrics for the evaluation of the optimization 
    ts_all = time.time()
    import psutil
    process = psutil.Process(os.getpid())
    cpu_time = process.cpu_times()[0] / float(2 ** 20)
    mem = process.memory_full_info()
    print("mem: \n {}".format(mem))
    
    
    # instantiate simulation object
    sim = PatternHitAndRun(bas_params, num_iter)
    
    # set initial x
    sim.set_x()
    print("set x_current {}".format(sim.data.loc["xc"]))
    
    # columns of parameters and results
    cols = list(sim.data.columns) + ['score']

    met = metrics.metrics(cols, replications, mem)
    
    # initialize 
    m = 0
    t = 10
    while(m < num_iter):
        print("--------- this is m {}-----------------------".format(m))
        # generate x_proposal
        sim.hit_and_run()
        t_send_data = time.time()
        # send x_proposal to EMEWS queue
        f_x = queue_map(0, sim.data.loc["xp"].to_dict())[0][0]
        sim.set_f_x(f_x)
        t_receive_data = time.time()
        met.calculate_simulation_time(t_send_data, t_receive_data)
        met.append_score(sim.f_x, sim.data.loc['xp'].to_dict(), cols)
        # accept xproposal depending on the algorithm used
        if(strategy == "IHR"):
            sim = improving_hit_and_run(sim)
        elif(strategy == "HNS"):
            sim, t = hide_and_seek(sim, m, t, met, cooling_schedule)
        else:
            pass
        m += 1
    te_all = time.time()
    metrics.summarize_results(met, ts_all, te_all)
