"""
This scripts implements two algorithms that are can be used for 
model exploration. These are Hide-and-Seek and Improving Hit-and-Run- 
The algorithms generate a sequence of points in a predefined
search space and evaluate these (for example by running a simulation) and
calculate the objective function value. 

Depending on the current state in the search space and the objective 
function value, other candidate points are proposed. 

**Improving Hit-and-Run (IHR)**

Improving Hit-and-Run only accepts improving points (points with a lower objective function value), following an exploitation strategy.

**Hide-and-Seek (HNS)**

Hide-and-Seek makes use of a cooling schedule and therefore, starts exploring the
search space (accepting non-improving points) and with an increasing number of 
iterations decreases the probability to accept non-improving points. For a higher 
number of iterations the algorithm approximates the behaviour of IHR. It may be easier
escape local minima with this algorithm. 

**Pure Random Search (PRS)**

PRS poses an exception, as the selection of points is independent from 
the current state. Points are selected randomly, utilising a pure
exploration strategy. Due to its exponential convergence properties it
can be used for benchmarking. 

Example
--------
>>> from bas import optimize
>>> import testfunction as tf
>>> problem = tf.problem('shcb', tf.six_hump_camel_back)
>>> strategy = "HNS"
>>> num_iter = 20
>>> save = True
>>> cooling_schedule = "geometric"
>>> data = pd.read_csv("../data/shcb_cont.csv")
>>> data = data.set_index("parameter")
>>> optimize(data, problem, strategy, num_iter, save, cooling_schedule)

The class PatternHitAndRun is instantiated with a pandas DataFrame, 
where the rows define the upper 'ub' and lower bounds 'lb' of the
decision variables as well as the step size 'ss'.
It returns an either discrete, continuous or mixed subclass of
*PatternHitAndRun*, depending on the dtype of the DataFrame columns. 
The column need to be named as below:
            +------------+-------------+------------+------------+
            | parameter  | lb          | ub         | ss         |
            +============+=============+============+============+
            | x1         | int value   | int value  | int value  |
            +------------+-------------+------------+------------+
            | x2         | float value | float value| float value|
            +------------+-------------+------------+------------+
            | ...        |             |            |            |
            +------------+-------------+------------+------------+
"""

import time
import sys
import metrics
import psutil
import os
import random
import ga_utils

from random_search import randomsearch
from patternhitandrun import PatternHitAndRun
from random import randrange, choices, triangular
from bas_box import *

import pandas as pd
import numpy as np


import eqpy

def transform_param(params):
    rows = ["lb", "ub", "ss"]
    df = pd.DataFrame()
    for param in range(len(params)):
        p = [params[param].lower, params[param].upper, params[param].sigma]
        df[params[param].name] = p
    df.index = rows
    df.index.name = 'parameter'
    return df


def explore(data, strategy, num_iter=100, save=True, cooling_schedule="adaptive", replications=1):
    """
    Optimize a given problem with a chosen strategy.
    Testfunctions can be defined by the user and need to be instantiated 
    as an object of the class ´problem´. 

    See testfunction for further information.

    Parameters
    -----------
    data : pandas DataFrame
           contains upper bound, lower bound and the step size      
    strategy : string
              optimization method 'HNS','IHR' or 'PRS'
    num_iter : int
              maximum number of iterations
    cooling_schedule : string
              only for 'hide-and-seek'; 'adaptive' or 'geometric'
    save : boolean, default=True
              wheather or not results shall be written

    Returns
    -------
    results : pandas DataFrame
              
    """
    if(strategy=='PRS'):
        return random_search(data, num_iter)
    else:
        return bas_optimize(data, strategy, num_iter, cooling_schedule, replications) 

        
def run():
    """
    Parameters
    -----------
    num_iter : int
              maximum number of iterations
    strategy : string
              optimization method 'HNS', 'IHR' or ''PRS
    cooling_schedule : string
              only for 'hide-and-seek'; 'adaptive' or 'geometric'
    save : boolean
              write output to csv
    """
    # get parameters from SWIFT and initialize EMEWS queues
    eqpy.OUT_put("Params")
    params = eqpy.IN_get()
    printf("Parameters: {}".format(params))
    (num_iter, replications, bas_parameters_file, strategy, cooling_schedule)  = eval('{}'.format(params))
    
    # transform parameters
    bas_parameters_file = bas_parameters_file.replace('\'', '\"')
    print(bas_parameters_file)
    bas_params = ga_utils.create_parameters(bas_parameters_file)
    bas_params = transform_param(bas_params)
    print("bas params {}".format(bas_params))
    minimum = explore(bas_params, strategy, num_iter, cooling_schedule, replications)
    print(minimum)

