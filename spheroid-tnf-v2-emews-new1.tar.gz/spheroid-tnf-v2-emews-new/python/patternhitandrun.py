"""
Pattern Hit-and-Run is a mixed (discrete/continuous) Monte Carlo Markov Chain sampler
introduced by Huseyin Onur Mete et al. ‘Pattern discrete and mixed Hit-and-Run for global optimization’. In: Journal of Global Optimization 50.4 (Aug. 2011), pp. 597–627., doi: 10.1007/s10898-010-9534-8.
"""

import sys
import random

import pandas as pd
import numpy as np

from random import choices
from scipy import stats

def randrange_float(start, stop, step):
    return random.randint(0, int((stop - start) / step)) * step + start

class HR:
    def __init__(self, data, m_max):
        self.m_max = m_max
        self.data = data
        self.f_x = 99*10**10
        self.f_x_last = 99*10**10
        self.tf = 0
        self.tb = 0
        
    def generate_path_length(self):
        """
        Calculates the length of the Box walk until stepping 
        out of the feasible region
        """
        self.data = self.data.astype('O')
        # calculate the number of steps until stepping out of S
        # using a minimum-ratio test
        self.data.loc["muhf"] = np.where(self.data.loc["d"] > 0,
                                     (self.data.loc["ub"]-self.data.loc['xc'])/
                                     self.data.loc["ss"],
                                     (self.data.loc['xc']-self.data.loc['lb'])/
                                     self.data.loc["ss"])
        
        self.data.loc["muhb"] = np.where(self.data.loc["d"] > 0,
                                    (self.data.loc['xc'] - self.data.loc['lb'])/
                                     self.data.loc["ss"],
                                     (self.data.loc["ub"] - self.data.loc['xc'])/
                                      self.data.loc["ss"])
        muhf =  self.data.loc["muhf"].min()                                
        muhb =  self.data.loc["muhb"].min()
        # get order of dimension that steps out of S
        #i_f = self.data.loc['muhf'].idxmin() 
        i_f = self.data.columns[self.data.loc['muhf'] == muhf][0] 
        i_f = np.where(self.data.columns==i_f)[0][0]
        #i_b = self.data.loc['muhb'].idxmin()
        i_b = self.data.columns[self.data.loc['muhb'] == muhb][0] 
        i_b = np.where(self.data.columns==i_b)[0][0]
        # calculate step length
        # -> tf is the number of points on the forward path
        self.tf = len(self.data.columns) * muhf + i_f - 1
        self.tb = len(self.data.columns) * muhb + i_b - 1
        
    def forward_path(self, p, permutation):
        """
        generates a proposal point on the forward_path
        """
        # calculate the number of cycles
        cycles = np.floor(p/len(self.data.loc['xc']))
        i_f = p - cycles * len(self.data.loc['xc'])
        # calculate xp
        self.data.loc["xp"] = self.data.loc['xc'] + self.data.loc["d"] * (self.data.loc["v"] * cycles)
        for i in range(int(i_f)):
            self.data.loc["xp"][permutation[i]] = (self.data.loc["xp"][permutation[i]] +
                                                       self.data.loc["d"][permutation[i]] *
                                                       self.data.loc["v"][permutation[i]])
            
    def backward_path(self, p, permutation):        # calculate the number of cycles
        cycles = np.floor(-p/len(self.data.loc['xc']))
        i_b = -p - cycles * len(self.data.loc['xc'])
        # go in the reverse order of ds
        permutation.reverse()
        # calculate xp
        self.data.loc["xp"] = self.data.loc['xc'] - self.data.loc["d"] * self.data.loc["v"] * cycles
        for i in range(int(i_b)-1):
            self.data.loc["xp"][permutation[i]]  = (self.data.loc["xp"][permutation[i]] -
                                                        self.data.loc["d"][permutation[i]] *
                                                        self.data.loc["v"][permutation[i]])
            
    def hit_and_run(self):
        """
        Generates a candidate point, using Pattern Hit-and-Run 
        """
        # step 1 - generate D
        self.data.loc["d"] = choices([-1,1], k=len(self.data.columns))
        # step 2 - generate random permutation
        permutation = random.sample(range(len(self.data.columns)), len(self.data.columns))
        # step 3.0 - BoxWalk 
        self.generate_path_length()
        self.generate_z(permutation)
        
    def set_x_current(self):
        self.data.loc['xc'] = self.data.loc['xp']
        
    def set_f_x(self, f_x):
        self.f_x = f_x
        
    def set_f_x_last(self, f_x_last):
        self.f_x_last = f_x_last


class ContHR(HR):
    def __init__(self, data, m_max):
        self.m_max = m_max
        self.data = data
        self.f_x = 99*10**10
        self.f_x_last = 99*10**10
        self.tf = 0
        self.tb = 0
        
    def set_x(self):
        self.data.loc['xc'] = self.data.apply(lambda
                                   row:randrange_float(row.loc["lb"],
                                                       row.loc["ub"],
                                                       row.loc["ss"]))
        
    def generate_z(self, permutation):
        """
        Generates a candidate point on the forward or backard path
        which is within the feasible region (search space).
        The length of the forward and backward path are calculated
        in the hit_and_run().

        Parameters
        -----------
        permutation : list of int

        """
        p = 0
        # v is the sampled step size 
        self.data.loc["v"] = self.data.loc['ss'].apply(lambda elem: randrange_float(0, elem, 10**(-10)) ) 
        # select a point on the forward or backward path
        while(p==0):
            p = random.randint(-int(self.tb), int(self.tf))
        if p > 0:
            self.forward_path(p, permutation)
        elif p < 0:
            self.backward_path(p, permutation)

class DiscreteHR(HR):
    
    def __init__(self, data, m_max):
        self.m_max = m_max
        self.data = data
        self.f_x = 99*10**10
        self.f_x_last = 99*10**10
        self.tf = 0
        self.tb = 0
        
    def set_x(self):
        self.data.loc['xc'] = self.data.apply(lambda
                                                 row:random.randrange(row.loc["lb"],
                                                                      row.loc["ub"]))
        
    def generate_z(self, permutation):
        """
        Generates a candidate point on the forward or backard path
        which is within the feasible region (search space).
        The length of the forward and backward path are calculated
        in the hit_and_run().
        
        Parameters
        -----------
        permutation : list of int
        """
        p = 0
        
        self.data.loc["v"] = self.data.loc['ss'].apply(lambda elem: random.randrange(1, elem) if elem>1 else 1)
        # select a point on the forward or backward path
        while(p==0):
            p = random.randint(-int(self.tb), int(self.tf))
        if p > 0:
            self.forward_path(p, permutation)
        elif p <= 0:
            self.backward_path(p, permutation)

            
class MixedHR(HR):
    def __init__(self, data, m_max):
        self.m_max = m_max
        self.data = data
        self.dfloat = data.select_dtypes(float)
        self.dint = data.select_dtypes(int)
        self.f_x = 99*10**10
        self.f_x_last = 99*10**10
        self.tf = 0
        self.tb = 0

    def generate_path_length(self):
        """
        Calculates the length of the Box walk until stepping 
        out of the feasible region
        """
        self.data = self.data.astype('O')
        # calculate the number of steps until stepping out of S
        self.data.loc["muhf"] = np.where(self.data.loc["d"] > 0,
                                     (self.data.loc["ub"]-self.data.loc['xc'])/
                                     self.data.loc["ss"],
                                     (self.data.loc['xc']-self.data.loc['lb'])/
                                     self.data.loc["ss"])
        
        self.data.loc["muhb"] = np.where(self.data.loc["d"] > 0,
                                    (self.data.loc['xc'] - self.data.loc['lb'])/
                                     self.data.loc["ss"],
                                     (self.data.loc["ub"] - self.data.loc['xc'])/
                                      self.data.loc["ss"])
        # the number of steps the forward/backward path
        muhf =  self.data.loc["muhf"].min()                                
        muhb =  self.data.loc["muhb"].min()
        # get order of dimension that steps out of S
        i_f = self.data.columns[self.data.loc['muhf'] == muhf][0] 
        i_f = np.where(self.data.columns==i_f)[0][0]
        i_b = self.data.columns[self.data.loc['muhb'] == muhb][0] 
        i_b = np.where(self.data.columns==i_b)[0][0]
        # calculate step length
        self.tf = len(self.data.columns) * muhf + i_f - 1
        self.tb = len(self.data.columns) * muhb + i_b - 1

        
    def set_x(self):
        """
        Generates the first point in the solution space, that is to be evaluated.
        Adds a column to `data`, named 'xc
        """
        self.dfloat = self.data.select_dtypes(float)
        self.dint = self.data.select_dtypes(int)
        # for floating point
        self.dfloat.loc['xc'] = self.dfloat.apply(lambda
                                   row:randrange_float(row.loc["lb"],
                                                       row.loc["ub"],
                                                       row.loc["ss"]))
        # for integer
        self.dint.loc['xc'] = self.dint.apply(lambda
                               row:random.randrange(row.loc["lb"],
                                                    row.loc["ub"]))
        # update xcurrent
        df = pd.concat([self.dfloat, self.dint], axis=1, sort=True)
        self.data = df.reindex(sorted(df.columns),axis=1)
 
    def generate_z(self, permutation):
        """
        Generates a candidate point on the forward or backard path
        which is within the feasible region (search space).
        The length of the forward and backward path are calculated
        in the hit_and_run().

        Parameters
        -----------
        permutation : list of int

        """
        p = 0
        float_criteria = self.data.loc['ss'].apply(lambda x: isinstance(x, float))
        self.dfloat = self.data[float_criteria.index[float_criteria]]
        self.dint = self.data[self.data.columns.difference(self.dfloat.columns)]
        #self.dint = self.data.loc[self.data.loc['ss'].apply(lambda x: isinstance(x, int))]
        #self.dfloat = self.data.select_dtypes(float)
        #self.dint = self.data.select_dtypes(int)
        dfloat_step = self.dfloat.loc['ss'].apply(lambda elem: randrange_float(0, elem, 10**(-10)))
        dint_step = self.dint.loc['ss'].apply(lambda elem: random.randrange(0, elem))
        d = dfloat_step.append(dint_step)
        self.data.loc["v"] = d.reindex(sorted(d.index))
        #select a point on the forward or backward path
        while(p==0):
            p = random.randint(-int(self.tb), int(self.tf))
        if p > 0:
            self.forward_path(p, permutation)
        elif p <= 0:
            self.backward_path(p, permutation)

class PatternHitAndRun:
    """
    Implements Pattern Hit-and-Run,
    a Monte-Carlo Markov Chain method to generate
    points in a high dimensional search space.


    Attributes
    ----------
    m_max : int
            maximum number of iterations/ length of the Markov Chain
    data : pandas DataFrame
            defining the search space

    Notes
    -----
    The columns are the decision variables.
    The row names are: ['lb', 'ub', 'ss'], 'lb' = lower bound, 'ub' = upper bound and 'ss' = step size. The row index is 'parameter'.

    +------------+------------+-----------+-----------+
    | parameter  | lb         | ub        | ss        |
    +============+============+===========+===========+
    | x1         | value      | value     | value     |
    +------------+------------+-----------+-----------+
    | x2         | value      | value     | value     |
    +------------+------------+-----------+-----------+
    | ...        |            |           |           |
    +------------+------------+-----------+-----------+

    Depending on the type of the bounds and step size different versions of Pattern Hit-and-Run are used: If all values are integer, the discrete version of the algorithms is employed. Vice versa, if all values are float, the continuous version is used. In case some columns contain integer and some floating point values the Mixed version is returned. 

    """
    def __new__(cls, data, m_max):
        if(all([data[col].dtype == float for col in data.columns])):
            print("Continuous PatternHitAndRun")
            return ContHR(data, m_max)
        elif(all([data[col].dtype == int for col in data.columns])):
            print("Discrete PatternHitAndRun")
            return DiscreteHR(data, m_max)
        if(int and float and not str in data.dtypes.unique()):
            return MixedHR(data, m_max)
        else:
            raise ValueError('{} does not exist!'.format(domain))

            
    def __init__(self, data, m_max):
        self.m_max = m_max # maximum number of iterations
        self.data = data
        
