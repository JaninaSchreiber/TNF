import threading
import time
import math
import csv
import json
import sys
import os

from scipy import stats

import pandas as pd
from random import randrange,choices, triangular

import ga_utils
import eqpy
import metrics

def obj_func():
    return 0

def printf(val):
    print(val)
    sys.stdout.flush()

        
def queue_map(obj_func, pops):
    # Note that the obj_func is not used
    # sending data that looks like:
    # [[a,b,c,d],[e,f,g,h],...]
    print("We are in queuemap {}".format(pops))
    #if not pops:
    #    return []
    eqpy.OUT_put(str(pops).replace("\'", "\""))
    result = eqpy.IN_get()
    split_result = result.split(',')
    # returns the objective function value
    return [(float(x),) for x in split_result]


def randomsearch(rs_params, num_iter):                                                                                                                            
    """                                                                                                                                                                    
    Use Random Search to explore the search space                                                                                                                          
                                                                                                                                                                           
    Parameters:                                                                                                                                                            
    ----------                                                                                                                                                             
    num_iter: int                                                                                                                                                          
               maximum number of iterations                                                                                                                                
    """                                                                                                                                                                    
    ts_all = time.time()                                                                                                                                                   
    import psutil                                                                                                                                                          
                                                                                                                                                                           
    process = psutil.Process(os.getpid())                                                                                                                                  
    mem = process.memory_full_info()                                                                                                                                       
                                                                                                                                                                           
    replications = 1                                                                                                                                                       
                                                                                                                                                                           
    rs = PatternHitAndRun(rs_params, num_iter)                                                                                                                             
    rs.set_x()                                                                                                                                                             
    cols = list(rs.data.columns) + ['score']                                                                                                                               
    met = metrics.metrics(cols, replications, mem)                                                                                                                         
    m=0                                                                                                                                                                    
    while(m < num_iter):                                                                                                                                                   
        rs.set_x()                                                                                                                                                         
        t_send_data = time.time()                 
        f_x = queue_map(0, rs._data.x_current.to_dict())[0][0]
        t_receive_data = time.time()                                                                                                                                       
        met.calculate_simulation_time(t_send_data, t_receive_data)                                                                                                         
        met.append_score(f_x, rs.data.loc['xc'].to_dict(), cols)                                                                                                           
        m += 1                                                                                                                                   
    te_all = time.time()                                                                                                           
    return metrics.summarize_results(met, ts_all, te_all)   
    
