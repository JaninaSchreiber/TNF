from __future__ import absolute_import
from __future__ import division
from __future__ import print_function


import threading
import random
import time
import math
import csv
import json
import sys
import pickle
import logging

import os
import numpy as np
import pandas as pd
from csa import CoupledAnnealer

try:
    xrange
except NameError:
    xrange = range

import eqpy, ga_utils

experiment_folder = os.getenv('TURBINE_OUTPUT')
checkpoint_file_input = os.getenv('CHECKPOINT_FILE')
checkpoint_file = os.path.join(experiment_folder,"ga_checkpoint.pkl")
logging.basicConfig(format='%(message)s',filename=os.path.join(experiment_folder,"generations.log"),level=logging.DEBUG)
# list of ga_utils parameter objects
transformer = None

        
def printf(val):
    print(val)
    sys.stdout.flush()

# Not used
def obj_func(x):
    return 0

# {"batch_size":512,"epochs":51,"activation":"softsign",
#"dense":"2000 1000 1000 500 100 50","optimizer":"adagrad","drop":0.1378,
#"learning_rate":0.0301,"conv":"25 25 25 25 25 1"}
def create_list_of_json_strings(list_of_lists, super_delim=";"):
    # create string of ; separated jsonified maps
    res = []
    global transformer
    for l in list_of_lists:
        jmap = {}
        for i,p in enumerate(transformer.ga_params):
            jmap[p.name] = l[i]

        jstring = json.dumps(jmap)
        res.append(jstring)

    return (super_delim.join(res))


def probe(solution, tgen):
    sigma = np.array([50, 3, 0.05]) * tgen
    probe_solution = []
    i=0
    printf(solution)
    for x in solution:
        probe_solution.append(x + random.normalvariate(0, sigma[i]))
        i=i+1
    return probe_solution


def queue_map(pops):
    # Note that the obj_func is not used
    # sending data that looks like:
    # [[a,b,c,d],[e,f,g,h],...]
    pops = {"user_parameters.time_add_tnf": pops[0],
            "user_parameters.duration_add_tnf": pops[1], 
            "user_parameters.concentration_tnf": pops[2]}
    printf(pops)
    if not pops:
        return []

    eqpy.OUT_put(str(pops).replace("\'", "\""))
    printf("eqpy.OUT_put")
    result = eqpy.IN_get()
    printf("results {}".format(result))
    split_result = result.split(';')
    # TODO determine if max'ing or min'ing and use -9999999 or 99999999
    return [(float(x),) if not math.isnan(float(x)) else (float(99999999),) for x in split_result]
    
    #return [(float(x),) for x in split_result]

def run():
    """
    :sparam num_iterations: number of generations
    :param seed: random seed
    :param ga parameters file name: ga parameters file name (e.g., "ga_params.json")
    :param num_population population of ga algorithm
    """
    eqpy.OUT_put("Params")
    parameters = eqpy.IN_get()
    # parse params
    printf("Parameters: {}".format(parameters))
    #(num_iterations, num_population, seed, ga_parameters_file) = eval('{}'.format(parameters))

    DIMENSION      = 3
    N_ANNEALERS    = 3
    STEPS          = 100
    #eqpy.OUT_put("DONE")
    # return the final population
    #eqpy.OUT_put("{}\n{}\n{}\n{}\n{}".format(create_list_of_json_strings(pop), ';'.join(fitnesses),
    #    start_time, log, end_time))

    initial_state = [(500, 5, 0.25), (100,9, 0.1), (800, 1, 0.4)]

    printf("getting here")
    annealer = CoupledAnnealer(
        queue_map,
        probe,
        n_annealers=N_ANNEALERS,
        initial_state=initial_state,
        steps=STEPS,
        processes=1,
        verbose=1,
    )
    annealer.anneal()
    energy, state = annealer.get_best()
    
    x = ', '.join(["{:,.5f}".format(x) for x in state])
    print("Energy: {:,.5f}, Position: ({})".format(energy, x))
   
