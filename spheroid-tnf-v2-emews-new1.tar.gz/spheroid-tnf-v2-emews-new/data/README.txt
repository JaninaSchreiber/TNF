Number of parameter inputs:
---------------------------
wc -l drug_policy_sweep_ABC.txt               # get number of lines in file 
>>> 19344 drug_policy_sweep_ABC.txt

wc -l drug_policy_sweep_param_n40.txt         # get number of lines in file    
>>> 64000 drug_policy_sweep_param_n40.txt
